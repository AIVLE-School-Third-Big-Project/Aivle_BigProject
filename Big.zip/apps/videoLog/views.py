from django.shortcuts import render

def videoLog(request) :
    return render(request, 'videoLog/videoLog.html')
